/***** BEGIN LICENSE BLOCK *****
 * Version: CPL 1.0/GPL 2.0/LGPL 2.1
 *
 * The contents of this file are subject to the Common Public
 * License Version 1.0 (the "License"); you may not use this file
 * except in compliance with the License. You may obtain a copy of
 * the License at http://www.eclipse.org/legal/cpl-v10.html
 *
 * Software distributed under the License is distributed on an "AS
 * IS" basis, WITHOUT WARRANTY OF ANY KIND, either express or
 * implied. See the License for the specific language governing
 * rights and limitations under the License.
 *
 * Copyright (C) 2007 Thomas Corbat <tcorbat@hsr.ch>
 * 
 * Alternatively, the contents of this file may be used under the terms of
 * either of the GNU General Public License Version 2 or later (the "GPL"),
 * or the GNU Lesser General Public License Version 2.1 or later (the "LGPL"),
 * in which case the provisions of the GPL or the LGPL are applicable instead
 * of those above. If you wish to allow use of your version of this file only
 * under the terms of either the GPL or the LGPL, and not to allow others to
 * use your version of this file under the terms of the CPL, indicate your
 * decision by deleting the provisions above and replace them with the notice
 * and other provisions required by the GPL or the LGPL. If you do not delete
 * the provisions above, a recipient may use your version of this file under
 * the terms of any one of the CPL, the GPL or the LGPL.
 ***** END LICENSE BLOCK *****/


package org.jruby.parser.postprocessor;

import java.util.Iterator;
import java.util.List;

import org.jruby.ast.ArrayNode;
import org.jruby.ast.BlockNode;
import org.jruby.ast.CommentNode;
import org.jruby.ast.ListNode;
import org.jruby.ast.NewlineNode;
import org.jruby.ast.Node;
import org.jruby.ast.RootNode;
import org.jruby.lexer.yacc.ISourcePosition;
import org.jruby.parser.RubyParserResult;

public class DefaultCommentPlacer implements PostProcessor{

    
    /**
     * An array of node classes which do NOT represent source code and therefore cannot get a comment assigned.
     */
    private static Class[] codelessNodes = new Class[]{
            NewlineNode.class, 
            RootNode.class,
            BlockNode.class,
            ArrayNode.class,
            ListNode.class
    };
    
    /* (non-Javadoc)
     * @see org.jruby.parser.postprocessor.PostProcessor#process(org.jruby.parser.RubyParserResult)
     */
    public void process(RubyParserResult result) {
        placeComments(result);
        
    }

    /**
     * 
     * @param result The parser result to process the comments for. The result gets modified.
     */
    public static void placeComments(RubyParserResult result) {
        
        List commentNodes = result.getCommentNodes();
        Iterator commentItr = commentNodes.iterator();
        Node rootNode = result.getAST();
        
        while(commentItr.hasNext()){
            CommentNode currentComment = (CommentNode)commentItr.next();
            ISourcePosition commentPosition = currentComment.getPosition();
            Node targetNode = getTargetNode(rootNode, commentPosition);
            if(targetNode == null){
                targetNode = rootNode;
            }
            
            targetNode.addComment(currentComment);
        }
    }

    
    /**
     * Determines the child node which belongs to the position of a comment.
     * @param currentNode The root node of the branch where the node is sought.
     * @param commentPosition The position of the comment which a node should be found for.
     * @return The node which the comment belongs to.
     */
    private static Node getTargetNode(Node currentNode, ISourcePosition commentPosition) {
        ISourcePosition currentPosition = currentNode.getPosition();
        if((currentPosition.getEndLine() == commentPosition.getStartLine() || currentPosition.getStartLine() >= commentPosition.getStartLine()) && !isCodelessNode(currentNode)){
            return currentNode;
        }
        
        List chlidNodes = currentNode.childNodes();
        Iterator childItr = chlidNodes.iterator();
        Node target = null;
        while(target == null && childItr.hasNext()){
            Node currentChild = (Node) childItr.next();
            target = getTargetNode(currentChild, commentPosition);
        }
        
        if(target == null && isEnclosingNode(currentNode.getPosition(), commentPosition)){
            return currentNode;
        }
        
        return target;
    }

    /**
     * Checks if the target node is codefree and thus cannot get a comment assigned.
     * @param targetNode The node which should be checked.
     * @return true if the node is codeless, false if not.
     */
    private static boolean isCodelessNode(Node targetNode) {
        boolean codeless = false;
        for(int i = 0; i < codelessNodes.length; i++){
            
            codeless |= (targetNode.getClass().equals(codelessNodes[i]));
        }

        return codeless;
    }

    /**
     * Checks if a node encloses a comment.
     * @param nodePosition Position of the node to check.
     * @param commentPosition Position of the comment to check.
     * @return true if the node encloses the comment, false if not.
     */
    private static boolean isEnclosingNode(ISourcePosition nodePosition, ISourcePosition commentPosition) {
        
        return nodePosition.getStartOffset() < commentPosition.getStartOffset() && nodePosition.getEndOffset() > commentPosition.getEndOffset();
    }

    
}
