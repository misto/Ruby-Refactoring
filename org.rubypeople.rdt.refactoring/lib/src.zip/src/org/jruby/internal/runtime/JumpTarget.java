/*
 * JumpTarget.java
 * 
 * Created on Jul 13, 2007, 7:23:57 PM
 * 
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */

package org.jruby.internal.runtime;

/**
 * Marker interface for jump targets. Only a jump target can receive a non-local return event.
 */
public interface JumpTarget {
}
