module Debugger
  module VarFunctions # :nodoc:
    def var_list(ary, bind = nil, kind='local')
      # TODO: this method should not be used anymore
      bind ||= @state.binding
      ary.sort!
      #for v in ary
      #  print "  %s => %s\n", v, eval(v, bind).inspect
      #end
      @printer.printXml("<variables>")
      for v in ary
        @printer.printVariable(v, bind, kind)	
      end
      @printer.printXml("</variables>")
    end
  end
  
  class VarConstantCommand < Command # :nodoc:
    include VarFunctions
    
    
    
    def regexp
      /^\s*v(?:ar)?\s+c(?:onst(?:ant)?)?\s+/
    end
    
    def execute
      obj = debug_eval(@match.post_match)
      unless obj.kind_of? Module
        print "Should be Class/Module: %s\n", @match.post_match
      else
        var_list(obj.constants, obj.module_eval{binding()})
      end
    end
    
    class << self
      def help_command
        'var'
      end
      
      def help(cmd)
        %{
          v[ar] c[onst] <object>\t\tshow constants of object
        }
      end
    end
  end
  
  class VarGlobalCommand < Command # :nodoc:
    include VarFunctions
    
    def regexp
      /^\s*v(?:ar)?\s+g(?:lobal)?\s*$/
    end
    
    def execute
      var_list(global_variables)
    end
    
    class << self
      def help_command
        'var'
      end
      
      def help(cmd)
        %{
          v[ar] g[lobal]\t\t\tshow global variables
        }
      end
    end
  end
  
  class VarInstanceCommand < Command # :nodoc:
    include VarFunctions
    
    def regexp
      # optional parameter:
      # 
      # BNF: v i (name|stackFrame objectId), 
      # stackFrame is second match, object Id third match
      # name will be matched but read from postMatch
      # e.g. v i 2 +0x123 eval object id +0x123 in stack frame 2
      /^\s*v(?:ar)?\s+i(?:nstance)?\s*(\d+)?\s+((?:[\\+-]0x)[\dabcdef]+)?/
    end
    
    def execute
      @printer.printElement("variables") do
        binding = getBinding(@match[1]) if @match[1]
        binding ||= @state.binding
        if (@match[2]) then
          obj = ObjectSpace._id2ref(@match[2].hex)
          if (!obj) then
            @printer.debug("Unknown object id : %s", @match[2])
          end
        else       
          obj = debug_eval(@match.post_match)
          @printer.debug("Evaluated #{@match.post_match} to #{obj}")
        end
        if (obj.class.name == "Array") then
          printArrayElements(obj)
          return
        end
        if (obj.class.name == "Hash") then
          printHashElements(obj)
          return
        end          
        instanceBinding = obj.instance_eval{binding()}	      
        obj.instance_variables.each {
          | instanceVar |
          @printer.printVariable(instanceVar, instanceBinding, 'instance')
        }
        classBinding = obj.class.class_eval('binding()')
        obj.class.class_variables.each {
          | classVar |
          @printer.printVariable(classVar, classBinding, 'class')
        }
        # I'd like to optimize getting the constants, but they are more dynamic
        # than one would expect from true constants.
        getConstantsInClass(obj.class).each {
          | constant |
          @printer.printVariable(constant, classBinding, 'constant')
        }
      end
    end
    
    def printArrayElements(array)
      index = 0 
      array.each { |e|
        @printer.printVariableValue('[' + index.to_s + ']', e, 'instance') 
        index += 1 
      }
    end
    
    def printHashElements(hash)
      hash.keys.each { | k |
        if k.class.name == "String"
          name = '\'' + k + '\''
        else
          name = k.to_s
        end
        @printer.printVariableValue(name, hash[k], 'instance') 
      }
    end
    
    #var_list(obj.instance_variables, obj.instance_eval{binding()})
    
    class << self
      def help_command
        'var'
      end
      
      def help(cmd)
        %{
          v[ar] i[nstance] <object>\tshow instance variables of object
        }
      end
    end
  end
  
  class VarLocalCommand < Command # :nodoc:
    include VarFunctions
    
    def regexp
      /^\s*v(?:ar)?\s+l(?:ocal)?\s*(\d+)?$/
    end
    
    def execute
      begin
        @printer.printElement("variables") do
          binding = getBinding(@match[1]) if @match[1]
          binding ||= @state.binding
          
          localVars = eval("local_variables", binding)
          if eval('self.to_s', binding) !~ /main/ then
            localVars << "self"
          end
          localVars.sort!
          for v in localVars
            @printer.printVariable(v, binding, 'local')	
          end
        end
      end
    end
    
    class << self
      def help_command
        'var'
      end
      
      def help(cmd)
        %{
          v[ar] l[ocal]\t\t\tshow local variables
        }
      end
    end
  end
end