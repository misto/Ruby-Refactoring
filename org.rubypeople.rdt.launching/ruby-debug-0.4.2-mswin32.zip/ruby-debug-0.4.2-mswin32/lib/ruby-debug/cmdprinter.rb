module Debugger
  class CmdPrinter
    attr_accessor :debug
    attr_accessor :socket
    def initialize(socket = $stdout)
      @debug = true
      @socket = socket
    end
    
    def out(*params)
      debugIntern(false, *params)
    end
    
    def printElement(name)
      yield
    end
    
    def printVariable(name, binding, kind)
      @socket.print "  %s => %s\n", name, eval(name, binding).inspect
    end
    
    def printBreakpoint(n, debugFuncName, file, pos, threadId)
      @socket.print("Breakpoint %d at %s:%s\n", n, file, pos)
    end
    
    def printException(file, pos, exception)
    end
    
    def printStepEnd(file, line, framesCount)
      @socket.print "%s:%d: %s", file, line, Debugger.line_at(file, line)
    end
    
    def printFrame(current, stackindex, file, line, id=nil)
      if current == stackindex
        @socket.print "--> "
      else
        @socket.print "    "
      end
      @socket.print "#%d %s:%s%s\n" % [stackindex + 1, file, line, (id ? ":in `#{id.id2name}'" : "")]
    end
    
    def printThread(context, is_debug_thread)
      d_flag = is_debug_thread ? '!' : ' '
      c_flag = context.thread == Thread.current ? '+' : ' '
      @socket.print "%s%s", c_flag, d_flag
      @socket.print "%d ", context.thnum
      @socket.print "%s\t", context.thread.inspect
      last_frame = context.frames.first
      if last_frame
        @socket.print "%s:%d", last_frame.file, last_frame.line
      end
      @socket.print "\n"
    end  
    
    def printLoadResult(file, exception=nil)
    end
    
    def debug(*params)
      debugIntern(true, *params)
    end
    
    def debugIntern(escape, *params)
      output = sprintf(*params)
      @socket.print("TRC: #{output}\n")
    end
  end
end
