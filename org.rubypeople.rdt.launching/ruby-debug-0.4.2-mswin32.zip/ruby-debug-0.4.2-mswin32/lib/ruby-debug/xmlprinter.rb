require 'cgi'
ECLIPSE_VERBOSE = true #defined? DebugVerbose
module Debugger
  class XmlPrinter
    attr_accessor :socket 
    def initialize(socket)
      @socket = socket
    end
    
    def out(*params)
      debugIntern(false, *params)
      if @socket then
        @socket.print(*params)
        @socket.print("\n")
      end    
    end
    
    def printElement(name) 
      out("<#{name}>")
      begin
        yield
      rescue StandardError => error
        debug("%s", error)          
      end
      out("</#{name}>")
    end
    
    def printVariable(name, binding, kind)
      printVariableValue(name, eval(name, binding), kind)
    end
    
    def printVariableValue(name, value, kind)
      if value == nil then
        out("<variable name=\"%s\" kind=\"%s\"/>", CGI.escapeHTML(name), kind)
        return
      end
      if value.class().name == "Array" or value.class().name == "Hash" then
        hasChildren = value.length > 0
        if value.length == 0 then
          valueString = "Empty " + value.class().name
        else
          valueString = value.class().name + " (" + value.length.to_s + " element(s))"
        end
      else 
        hasChildren = value.instance_variables.length > 0 || value.class.class_variables.length > 0
        valueString = value.to_s
        if valueString =~ /^\"/ then
          valueString.slice!(1..(valueString.length)-2) 
        end	  
      end
      out("<variable name=\"%s\" kind=\"%s\" value=\"%s\" type=\"%s\" hasChildren=\"%s\" objectId=\"%#+x\"/>", CGI.escapeHTML(name), kind, CGI.escapeHTML(valueString), value.class(), hasChildren, value.respond_to?(:object_id) ? value.object_id : value.id)
    end
    
    def printBreakpoint(n, debugFuncName, file, pos, threadId)
      # TODO: integrate Thread number
      out("<breakpoint file=\"%s\" line=\"%s\" threadId=\"%s\"/>", file, pos, threadId)
      #DEBUGGER__.get_thread_num()) 	      
    end
    
    def printException(file, pos, exception)
      out("<exception file=\"%s\" line=\"%s\" type=\"%s\" message=\"%s\" threadId=\"%s\"/>", file, pos, exception.class, CGI.escapeHTML(exception.to_s), DEBUGGER__.get_thread_num()) 	      
    end
    
    def printStepEnd(file, line, framesCount)
      #  TODO: get thread countDEBUGGER__.get_thread_num())    
      out("<suspended file=\"%s\" line=\"%s\" frames=\"%s\" threadId=\"%s\"/>", file, line, framesCount, 1)
    end
    
    def printFrame(pos, n, file, line, id=nil)
      out("<frame no=\"%s\" file=\"%s\" line=\"%s\"/>", n, file, line)
    end
    
    def printThread(context, is_debug)
      return if is_debug
      thread = context.thread
      
      out("<thread id=\"%s\" status=\"%s\"/>", context.thnum, thread.status)
    end  
    
    def printLoadResult(file, exception=nil)
      if exception then
        out("<loadResult file=\"%s\" exceptionType=\"%s\" exceptionMessage=\"%s\"/>", file, exception.class, CGI.escapeHTML(exception.to_s)) 	      
      else
        out("<loadResult file=\"%s\" status=\"OK\"/>", file) 	      
      end
    end
    
    def debug(*params)
      debugIntern(true, *params)
    end
    
    def debugIntern(escape, *params)
      if ECLIPSE_VERBOSE then
        output = sprintf(*params)
        output = CGI.escapeHTML(output) if escape
        STDERR.print(output)
        STDERR.print("\n")
        STDERR.flush
      end
    end
  end
end
