

module Debugger
  class Command # :nodoc:
    class << self
      def commands
        @commands ||= []
      end
      
      DEF_OPTIONS = {
        :event => true, 
        :control => false, 
        :always_run => false,
        :unknown => false,
      }
      
      def inherited(klass)
        DEF_OPTIONS.each do |o, v|
          klass.options[o] = v if klass.options[o].nil?
        end
        commands << klass
      end
      
      def load_commands
        dir = File.dirname(__FILE__)
        Dir[File.join(dir, 'commands', '*')].each do |file|
          require file
        end
      end
      
      def method_missing(meth, *args, &block)
        if meth.to_s =~ /^(.+?)=$/
          @options[$1.intern] = args.first
        else
          if @options.has_key?(meth)
            @options[meth]
          else
            super
          end
        end
      end
      
      def options
        @options ||= {}
      end
    end
    
    def initialize(state,printer= nil)
      @state = state
      @printer = printer
    end
    
    def match(input)
      @match = regexp.match(input)
    end
    
    protected
    
    def print(*args)
      @state.print(*args)
    end
    
    def confirm(msg)
      @state.confirm(msg) == 'y'
    end
    
    def debug_eval(str, binding = nil)
      binding ||= @state.binding
      #begin
        val = eval(str, binding)
#      rescue StandardError, ScriptError => e
#        at = eval("caller(1)", binding)
#        print "%s:%s\n", at.shift, e.to_s.sub(/\(eval\):1:(in `.*?':)?/, '')
#        for i in at
#          print "\tfrom %s\n", i
#        end
#        throw :debug_error
#      end
    end
    
    def debug_silent_eval(str)
      begin
        eval(str, @state.binding)
      rescue StandardError, ScriptError
        nil
      end
    end
    
    def line_at(file, line)
      Debugger.line_at(file, line)
    end
    
    def get_context(thnum)
      Debugger.contexts.find{|c| c.thnum == thnum}
    end
    
    def getBinding(pos)
      # returns frame info of frame pos, if pos is within bound,  nil otherwise
      return nil unless pos
      pos = pos.to_i
      pos -= 1
      if pos >= @state.context.frames.size || pos < 0 then
        @printer.debug("%i must be between %i and %i.", pos+1, 1, @frames.size)
        return nil
      end
      if (pos == @state.context.frames.size - 1)
        @printer.debug("root stack frame not yet supported")
        return nil
      end
      @printer.debug("Using frame %s for evaluation of variable.", pos)
      return @state.context.frames[pos].binding
    end
  end
  
  Command.load_commands
end