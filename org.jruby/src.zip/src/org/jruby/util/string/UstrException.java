package org.jruby.util.string;

public class UstrException extends java.lang.RuntimeException {
    private static final long serialVersionUID = 9147049197213160216L;

    public UstrException(String message) {
        super(message);
    }
}
